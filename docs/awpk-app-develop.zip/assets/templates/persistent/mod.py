# manifest: type=python, runtime=persistent, capabilities=["llm","db"], route="__NAME__"
# persistent 模板：任务落 aap.db + 前端轮询 + passUser 身份验签。
# 铁律：进程随时会被回收/重启 → 跨请求状态一律落库；禁止 print()；全部相对路径；不用 Cookie。
import base64
import binascii
import hashlib
import hmac
import json
import os
import threading
import time
import uuid

from flask import Flask, jsonify, request

app = Flask(__name__)


# ───────────────────────── 数据层（aap.db）─────────────────────────

def _init_db():
    aap.db.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            user_key TEXT NOT NULL,
            status TEXT NOT NULL,            -- queued | running | done | failed
            progress INTEGER DEFAULT 0,
            prompt TEXT,
            result TEXT,                     -- JSON 字符串
            error TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        )
    """)
    # 进程重启后遗留的 running/queued 任务不可能再有人处理，标记为失败，避免前端永远转圈
    aap.db.execute(
        "UPDATE tasks SET status='failed', error='服务重启，任务已中断，请重新提交', "
        "updated_at=datetime('now') WHERE status IN ('queued','running')"
    )


def _set(task_id, **cols):
    sets = ", ".join(f"{k}=?" for k in cols) + ", updated_at=datetime('now')"
    aap.db.execute(f"UPDATE tasks SET {sets} WHERE id=?", (*cols.values(), task_id))


try:
    _init_db()
except Exception as _e:  # noqa: BLE001
    aap.log.error("初始化数据库失败: %s", _e)


# ───────────────────────── 身份（passUser）─────────────────────────
# 勾选「注入用户身份」后，代理逐请求注入 x-aap-identity / x-aap-identity-sig，
# 并向环境变量注入 AAP_SIGN_SECRET。未勾选时无这些头 → 返回 None（匿名）。
# 注意：规范未写明头值/签名的编码格式，这里做宽容解析（推断实现）。
# 首次上传试运行时请用真实请求核对，对不上就按实际格式收紧。

def _b64url_decode(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _sig_candidates(sig: str):
    out = []
    try:
        out.append(bytes.fromhex(sig))
    except ValueError:
        pass
    for dec in (_b64url_decode, base64.b64decode):
        try:
            out.append(dec(sig))
        except (binascii.Error, ValueError):
            pass
    return out


def current_user():
    """验签通过返回 {"key": 账号键, "payload": {...}}，否则 None。"""
    raw = request.headers.get("x-aap-identity", "")
    sig = request.headers.get("x-aap-identity-sig", "")
    secret = os.environ.get("AAP_SIGN_SECRET", "")
    if not (raw and sig and secret):
        return None
    expected = hmac.new(secret.encode(), raw.encode(), hashlib.sha256).digest()
    if not any(hmac.compare_digest(expected, c) for c in _sig_candidates(sig)):
        aap.log.warning("身份签名校验失败")
        return None
    try:
        try:
            payload = json.loads(_b64url_decode(raw))
        except (ValueError, binascii.Error):
            payload = json.loads(raw)
    except ValueError:
        return None
    exp = float(payload.get("exp", 0))
    if exp > 1e12:  # 毫秒时间戳
        exp /= 1000
    if exp and exp < time.time():
        return None
    if payload.get("aud") != os.environ.get("AAP_APP_ID"):
        return None
    # 账号键不要只用 uid（本地账号与 OIDC 账号分号段）
    key = payload.get("subject") or f"{payload.get('kind')}:{payload.get('uid')}"
    return {"key": str(key), "payload": payload}


def _user_key() -> str:
    u = current_user()
    return u["key"] if u else "anonymous"


# ───────────────────────── 业务：后台任务 ─────────────────────────

def _run_task(task_id: str, prompt: str):
    try:
        _set(task_id, status="running", progress=10)
        resp = aap.llm.chat(
            messages=[
                {"role": "system", "content": "你是一个简洁的中文助手。"},
                {"role": "user", "content": prompt},
            ],
            max_tokens=1000,
        )
        _set(task_id, status="done", progress=100,
             result=json.dumps({"text": resp["content"]}, ensure_ascii=False))
        aap.log.info("任务完成 id=%s", task_id)
    except Exception as err:  # noqa: BLE001
        aap.log.error("任务失败 id=%s err=%s", task_id, err)
        _set(task_id, status="failed", error="生成失败，请稍后重试")


@app.route("/api/tasks", methods=["POST"])
def create_task():
    prompt = (request.get_json(silent=True) or {}).get("prompt", "").strip()
    if not prompt:
        return jsonify({"error": "请输入内容"}), 400
    task_id = uuid.uuid4().hex[:12]
    aap.db.execute(
        "INSERT INTO tasks (id, user_key, status, prompt) VALUES (?, ?, 'queued', ?)",
        (task_id, _user_key(), prompt),
    )
    # 线程里只做"正在处理中"的瞬时上下文；进度和结果都在 aap.db。
    # 若试运行发现线程内 aap.llm 的用户归因异常，改为在请求线程内同步执行。
    threading.Thread(target=_run_task, args=(task_id, prompt), daemon=True).start()
    return jsonify({"task_id": task_id})


@app.route("/api/tasks/<task_id>")
def get_task(task_id):
    rows = aap.db.query(
        "SELECT id, status, progress, result, error FROM tasks WHERE id=? AND user_key=?",
        (task_id, _user_key()),
    )
    if not rows:
        return jsonify({"error": "任务不存在"}), 404
    row = rows[0]
    row["result"] = json.loads(row["result"]) if row["result"] else None
    return jsonify(row)


@app.route("/api/tasks")
def list_tasks():
    rows = aap.db.query(
        "SELECT id, status, progress, created_at FROM tasks WHERE user_key=? ORDER BY created_at DESC LIMIT 20",
        (_user_key(),),
    )
    return jsonify({"tasks": rows})


# ───────────────────────── 页面 ─────────────────────────
# 所有资源/接口用相对路径（./api/…）；body 顶部留 56px 给平台悬浮条；不用 localStorage/Cookie。

PAGE = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>应用</title>
<style>
  body{margin:0;padding:56px 24px 24px;font:15px/1.6 system-ui,"PingFang SC","Microsoft YaHei",sans-serif}
  main{max-width:720px;margin:0 auto}
  textarea{width:100%;min-height:120px;padding:10px;box-sizing:border-box;border:1px solid #d0d7de;border-radius:8px;font:inherit}
  button{margin-top:10px;padding:8px 16px;border:0;border-radius:8px;background:#0969da;color:#fff;font:inherit;cursor:pointer}
  button:disabled{opacity:.5;cursor:default}
  #out{white-space:pre-wrap;margin-top:16px}
  .err{color:#cf222e}
</style></head><body><main>
<h1>应用</h1>
<textarea id="p" placeholder="输入内容"></textarea><br>
<button id="go">提交</button> <button id="copy">复制结果</button>
<div id="out"></div>
</main>
<script>
var last = "";
function legacyCopy(t){var a=document.createElement("textarea");a.value=t;a.style.position="fixed";a.style.opacity="0";
  document.body.appendChild(a);a.select();var ok=false;try{ok=document.execCommand("copy")}catch(e){}document.body.removeChild(a);return ok}
function copyText(t){
  if(navigator.clipboard&&navigator.clipboard.writeText){return navigator.clipboard.writeText(t).then(function(){return true},function(){return legacyCopy(t)})}
  return Promise.resolve(legacyCopy(t))}
function show(msg,isErr){var o=document.getElementById("out");o.className=isErr?"err":"";o.textContent=msg}
function poll(id){
  fetch("./api/tasks/"+id).then(function(r){return r.json()}).then(function(d){
    if(d.status==="done"){last=d.result.text;show(last);document.getElementById("go").disabled=false}
    else if(d.status==="failed"||d.error){show(d.error||"失败",true);document.getElementById("go").disabled=false}
    else{show("处理中… "+(d.progress||0)+"%");setTimeout(function(){poll(id)},1500)}
  }).catch(function(){show("网络异常，请重试",true);document.getElementById("go").disabled=false});
}
document.getElementById("go").onclick=function(){
  var p=document.getElementById("p").value;this.disabled=true;show("提交中…");
  fetch("./api/tasks",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:p})})
    .then(function(r){return r.json()}).then(function(d){
      if(d.error){show(d.error,true);document.getElementById("go").disabled=false}else{poll(d.task_id)}})
    .catch(function(){show("提交失败，请重试",true);document.getElementById("go").disabled=false});
};
document.getElementById("copy").onclick=function(){
  if(!last){show("还没有结果可复制",true);return}
  copyText(last).then(function(ok){show(ok===false?"复制失败，请手动复制":last)})};
</script></body></html>"""


@app.route("/")
def home():
    return PAGE


if __name__ == "__main__":
    # 端口由平台经 PORT 注入；只绑定 127.0.0.1
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 8080)))
