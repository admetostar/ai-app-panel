# manifest: type=python, runtime=invoked, capabilities=["llm"]
# 入口：handle(input, aap)。invoked 每次调用都是全新进程，不要依赖内存状态。
# 禁止 print()；日志用 aap.log；失败返回 {"error": "中文说明"}。


def handle(input: dict, aap) -> dict:
    """
    input  = 用户表单提交的结构化数据（字段由平台上配置的入参 Schema 决定）
    return = 渲染给用户的结构化结果（必须可 JSON 序列化）
    """
    text = str(input.get("text", "")).strip()
    if not text:
        return {"error": "请输入要处理的内容"}

    aap.log.info("收到请求 len=%d", len(text))  # 只记长度，不记原文
    try:
        resp = aap.llm.chat(
            messages=[
                {"role": "system", "content": "你是一个简洁的中文助手。"},
                {"role": "user", "content": f"请用三句话总结：\n{text}"},
            ],
            max_tokens=800,  # 显式指定，便于平台预检额度
        )
    except Exception as err:  # noqa: BLE001 — 顶层兜底，给用户友好提示
        aap.log.error("LLM 调用失败: %s", err)
        return {"error": "生成失败，请稍后重试"}

    aap.log.info("完成 model=%s usage=%s", resp.get("model"), resp.get("usage"))
    return {"summary": resp["content"], "model": resp.get("model")}
