# manifest.json 规范

目录
- [完整示例](#完整示例)
- [字段说明](#字段说明)
- [三条铁律](#三条铁律)
- [env：环境变量 / 机密声明](#env环境变量--机密声明)
- [requirements：pip 依赖声明](#requirementspip-依赖声明)

## 完整示例

```jsonc
{
  "name": "stock-summary",          // 小写字母数字连字符，全局唯一
  "display_name": "股票摘要助手",
  "version": "1.0.0",
  "type": "python",                  // "html" | "python"
  "entry": "mod.py",                 // python 必填；html 固定 index.html；仅限包内相对路径
  "description": "输入股票代码，生成中文投资摘要",
  "author": "someone",
  "runtime": "invoked",              // "invoked" | "persistent"（仅 python）
  "capabilities": ["llm", "db"],     // llm / db / storage，按需声明
  "network": ["api.example-data.com"],   // 出站域名白名单；无需联网则 []
  "env": {
    "ABUSEIPDB_API_KEY": { "required": true, "secret": true, "pattern": "^[a-f0-9]{80}$", "description": "AbuseIPDB 密钥" },
    "MAX_CONCURRENCY": { "required": false, "default": "4", "description": "并发上限" }
  },
  "requirements": ["flask>=3.0"],    // 仅当需要标准库 + 预置框架之外的库
  "route": "stock-summary"           // 仅 persistent：平台路由前缀 /app/stock-summary/
}
```

（真实 JSON 文件里不能有注释，上面只为说明。）

## 字段说明

| 字段 | 必填 | 说明 |
|---|---|---|
| `name` | 是 | `^[a-z0-9]+(-[a-z0-9]+)*$`，全局唯一 |
| `display_name` / `description` / `author` / `version` | 是 | 展示与审核用 |
| `type` | 是 | `html` 或 `python` |
| `entry` | 是 | python 为 `mod.py`；html 固定 `index.html`；含 `../` 或绝对路径上传即拒 |
| `runtime` | python 必填 | `invoked`（默认选择）或 `persistent` |
| `capabilities` | 是 | 子集 of `llm` / `db` / `storage`；不用的不写 |
| `network` | 是 | 域名逐条列出（纯主机名，不带 scheme/路径）；不联网写 `[]` |
| `env` | 否 | 见下 |
| `requirements` | 否 | 见下 |
| `route` | persistent 必填 | 平台内路由前缀 |

## 三条铁律

1. `capabilities` 和 `network` 是**审批依据**——写了什么管理员就按什么审；上线后改白名单 = 重新提审。
2. 不声明的能力**调用直接报错**。宁少勿多。
3. `persistent` 常驻占用资源，审查更严：没有持续服务需求的（哪怕要调 LLM）一律用 `invoked`。

## env：环境变量 / 机密声明

需要外部配置（第三方 API key、模型名、阈值……）时，在 `env` 声明，**不要写死在代码里，也不要要求用户把 key 交给你**。

```jsonc
"env": {
  "变量名": "描述",   // 速记写法 = required 必填
  "变量名": { "required": true, "secret": true, "pattern": "^…$", "default": "…", "description": "…" }
}
```

| 字段 | 说明 |
|---|---|
| `required` | 默认 `true`。必填变量未配置时，平台拒绝执行/拉起并提示缺哪个 |
| `secret` | 默认 `false`。`true` = AES-256-GCM 加密落盘，平台界面只写不读（仅显示尾 4 位） |
| `pattern` | 可选格式校验正则（保存配置时执行；自带 `^` `$` 锚点） |
| `default` | 可选；**机密变量不允许 default**；值必须是字符串 |
| `description` | 展示在配置界面，说明这是什么、去哪获取 |

行为与纪律：

- 值由归属者/管理员上传后在平台「环境变量」填（用户中心·我的应用 / 管理后台·应用管理）；沙箱每次启动注入为进程环境变量，代码里 `os.environ["变量名"]` 读取。
- persistent 修改配置后自动重启进程（下次访问生效）；invoked 每次天然生效。
- 单包最多 **16** 个变量；值长度 ≤ **8192** 字符。
- **不要把环境变量值打进 `aap.log`。**
- **保留名不可声明**（声明即上传失败）：`AAP_*`、`PORT`、`PATH`、`HOME`、`HTTP_PROXY` / `HTTPS_PROXY` / `NO_PROXY`、`PYTHON*`、`SSL_CERT_*`、`SANDBOX_*`、`NODE_OPTIONS` 等平台注入面。
- 平台自动注入、可直接读取的保留变量：`PORT`（persistent）、`AAP_APP_ID`、`AAP_SIGN_SECRET`（仅勾选 passUser 的包）。

## requirements：pip 依赖声明

超出标准库 + 平台预置框架（flask 已预置，**无需声明**）的第三方库，在 `requirements` 声明，上传时平台自动安装到应用私有目录，沙箱内直接 `import`。**不允许任何形式的运行时自装。**

```jsonc
"requirements": ["requests==2.32.3", "beautifulsoup4>=4.12,<5"]
```

- **声明制 = 审批依据**：管理员照单审依赖；改依赖 = 重新提审。
- **写法**：标准 pip 需求串（`名称[extras] 版本约束`）。建议带上限或精确版本——不带约束 = 装当时最新版，升级后行为可能变。**不支持** URL / 本地路径 / `-r`（上传即拒）。
- **安装时机**：上传/版本更新时执行 `pip install --only-binary=:all: --target <应用目录>/.deps`；**失败 = 上传被拒**，错误原样返回（网络/镜像问题请管理员检查平台「pip 索引源」设置）。
- **只装 wheel**：无预编译 wheel 的源码包装不了，会明确报错——换纯 Python 等价库或联系管理员。
- 版本更新不再声明的依赖会被清掉；依赖装在应用数据目录，平台升级/重建不影响。
- 注意：即使声明了 `requests`，**出站网络仍必须走 `aap.http.fetch`**——沙箱里没有直连外网的通道。`requirements` 适合解析、计算、格式处理类库（bs4、pandas、openpyxl 等），不是用来绕过网络限制的。
