# 规范版本演进（v0.2 → v0.2.6，2026-09）

仅在需要判断某特性是否受目标平台支持时查阅。配套平台 PRD v0.3+。

| 版本 | 变更 |
|---|---|
| v0.2 | 新增日志规范 `aap.log`（统一收口到平台）、统一页面元素（返回个人中心/退出登录悬浮条）、本地调试沙箱 `aap-dev` |
| v0.2.1 | HTML 包由平台托管上线（上传即托管生效）；Python 沙箱运行时（invoked / persistent）实装；LLM 自动签发：包上传即自动配置网关凭据，声明 `llm` 能力的包开放模型调用，未声明的包 LLM 接口一律 403（能力闸在网关侧强制） |
| v0.2.2 | manifest 新增 `env`（环境变量/机密声明，AES-256-GCM 加密存储、界面只写不读、沙箱启动时注入）；`aap.http.fetch` 支持 `headers` 并透传上游状态码 |
| v0.2.3 | 新增沙箱前端纪律（禁 localStorage/密钥收集、剪贴板降级）；persistent 状态纪律（进程会被空闲回收/重启，状态落 `aap.db`）；实战案例与坑清单 |
| v0.2.4 | skill frontmatter（可安装自动触发）；硬性约束与自检清单合并为单一清单；`aap-dev` 按实装收窄为 `run` + mock |
| v0.2.5 | passUser 应用身份验签密钥自动下发：勾选「注入用户身份」的包自动注入 `AAP_SIGN_SECRET`（`AAP_` 保留名）；后台轮换密钥或切换 passUser 自动停起 persistent 进程；上游（external）应用在管理后台表单复制密钥 |
| v0.2.6 | manifest 新增 `requirements`（上传时自动 `pip install`，只装 wheel，失败=上传被拒，版本更新不再声明的依赖自动清除）；平台新增「pip 索引源」设置（`PIP_INDEX_URL`，国内镜像）；native/FPK 形态启动自检补装预置框架 flask |

**`aap-dev` 当前实装范围**：`aap-dev run mod.py --input input.json [--reset]`（invoked，mock LLM）。
`serve`（persistent 本地服务）、`--llm real`、`--submit`（调试日志回传平台）随平台 M4 提供，**当前未实装，勿依赖**。

**接口面变更规则**：`aap.*` 接口面变更必须升版本并同步平台内部实现约定。本技能内容随之更新。
