# aap.* 能力接口

平台向 `mod.py` 注入全局对象 `aap`（无需 import、无需任何密钥）。**只存在以下接口，没有别的。**

目录
- [aap.llm.chat](#aapllmchat--调用大模型)
- [aap.db](#aapdb--数据库)
- [aap.storage](#aapstorage--文件存储)
- [aap.http.fetch](#aaphttpfetch--出站-http)
- [aap.log](#aaplog--日志)

## aap.llm.chat — 调用大模型

需在 manifest 声明 `capabilities: ["llm"]`；未声明的包调用一律 403（网关侧强制，绕过代理直连同样无效）。

```python
resp = aap.llm.chat(
    messages=[
        {"role": "system", "content": "你是一个财务分析助手"},
        {"role": "user", "content": f"总结 {text} 的要点"},
    ],
    model="glm-4.7",     # 可选；不填用平台默认模型
    temperature=0.7,     # 可选
    max_tokens=2000,     # 可选，建议写——影响预检额度预估
)
resp["content"]          # 助手回复文本
resp["usage"]            # {"prompt_tokens":..., "completion_tokens":...}
resp.get("model")        # 实际模型名
```

- 走平台 LLM 网关（OpenAI 兼容），token 计入**发起调用的用户**的额度池；不用管 key、计费、限流。
- 模型名以管理员的模型目录为准，写错会返回明确错误。
- `stream=True` 返回迭代器，逐段 yield 增量文本。
- 不传 `max_tokens` 时生成上限由平台 `LLM_SANDBOX_MAX_TOKENS` 统一治理（0 = 不限）；显式指定可精确控制预检额度。
- 余额不足时预检失败（HTTP 402 语义），按异常处理并给用户友好提示。

## aap.db — 数据库

需声明 `"db"`。每包独立 SQLite（自动创建、自动命名空间、互不可见），库内可用完整 SQL。

```python
aap.db.execute("""
    CREATE TABLE IF NOT EXISTS records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_key TEXT NOT NULL,
        code TEXT NOT NULL,
        summary TEXT,
        created_at TEXT DEFAULT (datetime('now'))
    )
""")
aap.db.execute("INSERT INTO records (user_key, code, summary) VALUES (?, ?, ?)", ("u_1001", "600519", "……"))
rows = aap.db.query("SELECT code, summary FROM records WHERE user_key = ? ORDER BY id DESC LIMIT 10", ("u_1001",))
# rows -> list[dict]
```

- SQL 只作用于本包的库；平台业务表与其他包数据物理隔离，无跨库 join。
- 建表用 `CREATE TABLE IF NOT EXISTS`（每次进程启动都会再执行）。
- **参数一律用 `?` 占位符**，不要拼接字符串——防注入是包作者的责任。
- 有容量限额，超限报错；平台自动 commit。
- 典型用途：**任务/结果表**（persistent 状态纪律）、**按平台用户隔离的数据**（行键带 `user_key`）。

## aap.storage — 文件存储

需声明 `"storage"`。每包独立配额，有单包容量与单文件大小限额。

```python
aap.storage.put("uploads/abc.pdf", binary_bytes)
data = aap.storage.get("uploads/abc.pdf")        # -> bytes
aap.storage.delete("uploads/abc.pdf")
files = aap.storage.list(prefix="uploads/")
```

适合用户上传件、生成结果缓存。invoked 出参必须可 JSON 序列化——二进制结果存 storage，返回路径/链接而不是 bytes。

## aap.http.fetch — 出站 HTTP

需 manifest `network` 列出域名（不需要单独 capability）。

```python
resp = aap.http.fetch("https://api.example-data.com/v1/quote?code=600519")
# resp = {"status": 上游状态码, "body": 上游响应文本（≤500KB）}

# 鉴权 API：headers 传自定义请求头，密钥从 os.environ 取
resp = aap.http.fetch(
    "https://api.example-data.com/v2/check",
    headers={"Key": os.environ["EXAMPLE_API_KEY"], "Accept": "application/json"},
)
```

- 域名必须**逐条写在 `network`**，未声明直接被代理拒绝（以异常抛出）。
- **仅支持 GET**；`headers` 里的逐跳头（Host / Connection / Content-Length 等）会被剥除。
- 执行点在平台代理侧，无法绕过；没有 socket / os.system 可用。
- **上游错误码不抛异常**，经 `resp["status"]` 判断——401/429/5xx 必须逐分支处理，别当成功。
- `body` 是文本且 ≤500KB；需要 JSON 自行 `json.loads(resp["body"])`。

## aap.log — 日志

平台注入配置好的日志处理器；`aap.log` 与标准 `logging` 等价，所有日志统一收口进平台「运行记录」（本地调试、试运行、线上全走这一条通道）。沙箱内无网络、无文件写权限，别想自建日志出口。

```python
aap.log.debug("解析输入: code=%s", code)         # 过程细节
aap.log.info("开始生成摘要 model=%s", model)     # 关键业务动作
aap.log.warning("上游返回空，使用降级文案")       # 可恢复异常
aap.log.error("生成失败: %s", err)               # 失败，同时返回 {"error": ...}
```

| 级别 | 用途 | 线上保留 |
|---|---|---|
| DEBUG | 过程细节、中间值 | 否（仅本地调试/试运行） |
| INFO | 关键业务动作与结果 | 是 |
| WARNING | 可恢复异常、降级、重试 | 是 |
| ERROR | 失败；必须配合返回 `{"error": "中文说明"}` | 是 |

硬性要求：

1. **禁止 `print()`**：stdout 是 invoked 的结构化出参通道，print 会污染协议、日志丢失。
2. **脱敏**：不打 key/token/密码/环境变量值；手机号、邮箱、正文原文打掩码（`u_100***`、`138****1234`）。
3. **限量**：单次运行有条数与字节上限，超限截断并标记 truncated；高频循环不要逐条 DEBUG，聚合成一条。
4. **日志不是返回值**：业务结果走 `return` / HTTP 响应。
