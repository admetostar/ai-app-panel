# 移植/重构现有项目 · 案例 · 坑清单

## 方法论：逐项替换自建设施为平台能力

移植的实质是**把自建基础设施换成平台能力，业务逻辑原样保留**。先盘点原项目里有哪些"基础设施代码"，再对照下表删除/替换：

| 自建设施 | 平台替代 |
|---|---|
| 用户/登录/OIDC/人机验证 | 平台统一账号 + 应用可见性（public / login / restricted / private） |
| LLM 接入（多上游/key/计费） | `aap.llm.chat` + passUser 归因（按浏览用户扣费，余额预检 402） |
| 密钥/配置保管 | manifest `env`（`secret: true`）+ 平台环境变量 |
| 中心数据库 | `aap.db`（行键带 user_key 隔离各用户） |
| 审计/运行记录 | 平台运行记录 + audit_logs（自动） |
| 出站 API 调用（requests/axios） | `aap.http.fetch` + manifest `network` 白名单 |
| 文件上传/落盘 | `aap.storage` |
| localStorage / Cookie 会话 | 后端 `aap.db` + 身份头 |
| 后台任务队列/内存任务表 | `aap.db` 任务表 + 前端轮询 |

移植步骤建议：

1. 通读原项目，列出：入口、路由、外部调用（域名清单）、密钥/配置项、持久化数据、前端存储用法、依赖库。
2. 选形态：有页面/多路由 → persistent；单次处理 → invoked 或拆分成 invoked。
3. 对照上表逐项替换，**先删后写**：认证、计费、key 管理整体删除，包内只剩业务编排。
4. 依赖：能用标准库/flask 就不声明；必须第三方的写进 `requirements`（只装 wheel，注意是否有 wheel）。
5. 把域名清单写进 `network`，密钥写进 `env`。
6. 跑 `validate_aap.py` 清零 ERROR，再模拟运行，再打包。

## 案例

**案例 A · ip-analyzer**（Flask + AbuseIPDB → persistent 包）
五个替换：`requests` → `aap.http.fetch`（带鉴权头）；密钥 UI 收集 → `env` 注入；socket 反查删除；localStorage 清除；任务状态落 `aap.db`。

**案例 B · llm-proofread**（React19 + Express + tRPC + MySQL → 全新 persistent 包）
自建用户系统、LLM 多上游接入、密钥保管、审计日志**整体删除**；包内只剩校对编排、规则引擎、diff 呈现、每用户提示词/词库（`aap.db`）。

**另一个实测案例**：native/FPK 形态曾因宿主缺 flask，persistent 包静默 503 崩溃循环；v0.2.6 起平台在启动时自检补装预置框架 flask。

## 坑清单（全部实测踩过）

| 坑 | 症状 | 正确做法 |
|---|---|---|
| persistent 进程内存放任务/结果 | 空闲回收（约 5 分钟）后「任务不存在」 | 状态落 `aap.db` |
| `socket` / 直连网络 / requests | 平台网络守卫报错，且违反规范 | `aap.http.fetch`（headers 带鉴权头） |
| 忽略 `resp["status"]` | 上游 401/429 被当成功处理 | 逐分支处理状态码 |
| persistent 响应 Set-Cookie | 被平台剥离，浏览器拿不到 | 会话态落 `aap.db` + 身份头 |
| `print()` 调试 | invoked 下污染 JSON 出参；日志丢失 | `aap.log` / `logging` |
| 前端用 `localStorage` | 沙箱 `SecurityError`，整段脚本崩 | 内存变量 + 后端落库 |
| 页面写 `/static/x.css`、`fetch('/api/x')` | 404：应用实际挂在 `/app/<route>/` 下 | 全部相对路径 `./…` |
| `navigator.clipboard` 无降级 | 沙箱下复制无反应 | 加 `execCommand('copy')` 降级 |
| 账号键只用 `uid` | 本地账号与 OIDC 账号撞号 | 用 `(kind, uid)` 或 `subject` |
| 声明了 `requirements` 但库无 wheel | 上传被拒，报错原样返回 | 换纯 Python 等价库 |
| env 声明了保留名（PORT、AAP_* 等） | 上传失败 | 改名；保留变量平台自动注入 |
