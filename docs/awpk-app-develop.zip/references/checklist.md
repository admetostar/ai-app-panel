# 交付自检清单

`[auto]` = `scripts/validate_aap.py` 会自动检查；其余需要你人工确认。交付前逐条过。

## manifest 与能力声明

- [ ] [auto] manifest 字段齐备，`name` 格式正确，`type/runtime/entry/route` 组合合法
- [ ] [auto] `capabilities` 与代码实际调用一致（用了没声明 = ERROR；声明了没用 = WARN）
- [ ] [auto] `aap.http.fetch` 的域名全部在 `network`；`network` 是纯主机名
- [ ] [auto] `env` 变量名不在保留名内、≤16 个、机密变量无 default、pattern 是合法正则
- [ ] [auto] 代码里 `os.environ` 读取的变量都已在 `env` 声明（或是平台保留变量）
- [ ] [auto] `requirements` 无 URL / 本地路径 / `-r`；代码里的第三方 import 都在其中
- [ ] [auto] 没有硬编码密钥/令牌
- [ ] 没有任何方式向使用者索要密钥

## 代码边界

- [ ] [auto] Python 包入口是单文件 `mod.py`，语法可解析
- [ ] [auto] 无 socket / subprocess / os.system / requests / urllib 等自建网络或进程出口
- [ ] [auto] invoked 定义了 `handle(input, aap)`
- [ ] invoked 出入参可 JSON 序列化（二进制存 storage 给路径）；长任务已拆分或加进度说明
- [ ] 上游状态码 `resp["status"]` 逐分支处理
- [ ] [auto-ish] 错误路径返回 `{"error": "人类可读的中文说明"}`

## 运行时状态

- [ ] invoked 无状态，跨请求状态落 `aap.db` / `aap.storage`
- [ ] [auto-ish] persistent 没有把任务/结果放在模块级 dict/list（validate 会按变量名启发式提示）
- [ ] [auto] persistent 使用 `PORT` 环境变量 + `127.0.0.1`
- [ ] [auto] persistent 不使用 Cookie / Flask session
- [ ] 按用户隔离数据时行键自带 user_key；persistent 从 `x-aap-identity` 头验签（`AAP_SIGN_SECRET`），账号键用 `(kind, uid)` 或 `subject`

## 日志

- [ ] [auto] 没有 `print()`
- [ ] [auto] 没有把 `os.environ` 的值传给日志调用
- [ ] 级别语义正确、敏感信息脱敏、高频循环聚合不逐条 DEBUG

## 前端（HTML 工具与 persistent 页面）

- [ ] [auto] 无 localStorage / sessionStorage / document.cookie
- [ ] [auto] 用了 `navigator.clipboard` 就带 `execCommand('copy')` 降级
- [ ] [auto] 无绝对路径资源/接口（`src="/…"`、`fetch('/…')`）
- [ ] [auto] 无密钥输入框（`type="password"`、"API Key" 输入）
- [ ] persistent：右上角留白（220×48px）不遮挡平台按钮；没有自建登录/登出入口

## 交付

- [ ] 已用 `mock_run.py`（或官方 `aap-dev run`）跑通；persistent 尚无本地 serve，需在交付说明里写明"上传后试运行验证"
- [ ] 打包用 `pack_aap.py`（manifest.json 在 ZIP 根部，不含 `__pycache__` / `.aap-dev` / `.deps`）
- [ ] 交付说明包含：包信息、env 配置清单、入参 Schema、自测步骤、已知限制
