# 运行时模型与前端纪律

目录
- [invoked：按调用](#invoked按调用默认选择)
- [persistent：持久服务](#persistent持久服务)
- [任务落库模式](#任务落库模式persistent-标准写法)
- [passUser：按用户隔离数据](#passuser按用户隔离数据)
- [统一页面元素](#统一页面元素persistent)
- [沙箱前端纪律](#沙箱前端纪律)

## invoked：按调用（默认选择）

```
用户点工具 → 填表单提交 → 平台起全新进程 → 执行 handle(input, aap) → 返回 JSON → 进程销毁
```

- **无状态**：不要依赖进程内存；要保留就写 `aap.db` / `aap.storage`。
- 单次执行有超时（平台默认），不要做长任务；长任务拆分或在返回里给进度说明。
- `input` 是用户表单提交的结构化数据，字段由平台上配置的入参 Schema 生成——**上传后要在平台给包配置与 `input` 键一致的入参 Schema**，并写进交付说明。
- 出入参必须可 JSON 序列化。
- 入口签名：`def handle(input: dict, aap) -> dict`。

## persistent：持久服务

平台拉起长驻进程，你的应用是一个普通 HTTP 服务，挂在平台反向代理之下：

- 对外地址：`https://<平台域名>/app/<route>/`（路径模式，**带前缀**）。
- 平台代管：HTTPS、限流、审计、健康检查、崩溃重启、空闲回收。
- 监听端口由环境变量 `PORT` 注入，bind `127.0.0.1`，**不要自己挑端口**。
- 进程无外网，出站走 `aap.http.fetch`。
- Web 框架用平台预置的 flask，无需声明依赖。

**状态纪律（重要）**：进程随时会消失重来——空闲回收（约 5 分钟无访问）、崩溃重启、平台重新部署。任务、结果、草稿等跨请求状态一律落 `aap.db`（任务表 + 进度列 + 结果 JSON 列 + 前端轮询）。实测教训：任务放内存字典 → 用户中场休息 5 分钟 → 进程被回收 → 「任务不存在」。

**路径前缀**（最容易踩的坑）：

- 应用挂在 `/app/<route>/` 下，不是根路径。
- 页面里所有资源/接口用**相对路径**（`./static/x.css`、`./api/tasks`），不要写 `/static/x.css`。
- 需要拼绝对路径时用 `X-Forwarded-Prefix` 请求头。

**不要依赖 Cookie**：平台剥离沙箱响应的 Set-Cookie（防 cookie tossing）。会话态走 `aap.db` + 身份头。

## 任务落库模式（persistent 标准写法）

`assets/templates/persistent/mod.py` 已实现，要点：

1. 表 `tasks(id, user_key, status, progress, result, error, created_at, updated_at)`。
2. `POST ./api/tasks` 只负责建行并启动后台线程，立即返回 `task_id`。
3. 后台线程每个阶段更新 `status/progress`，完成时把结果 JSON 写入 `result`。
4. 前端 `GET ./api/tasks/<id>` 轮询。
5. 进程启动时把遗留的 `running` 任务标成 `failed`（"服务重启，任务中断"），避免用户永远转圈。
6. 若试运行发现后台线程里 `aap.llm` 的用户归因或上下文异常，改为在请求线程内同步执行。

## passUser：按用户隔离数据

接入时勾选「注入用户身份」的包：

- 反向代理逐请求注入 `x-aap-identity` 与 `x-aap-identity-sig` 签名头，payload 含 `uid / kind / subject / aud / jti / exp`。
- 沙箱环境变量自动注入 `AAP_SIGN_SECRET`（平台全局身份签名密钥；`AAP_` 保留名，manifest 不可声明覆盖）。后台轮换密钥或切换 passUser 开关会自动停起 persistent 进程。
- 验签：用 `AAP_SIGN_SECRET` 重算 HMAC，`hmac.compare_digest` 比对；校验 `exp` 未过期、`aud == os.environ["AAP_APP_ID"]`；通过后才能信任 payload。
- **账号键不要只用 `uid`**（本地账号与 OIDC 账号分号段，可能撞号），用 `(kind, uid)` 组合或 `subject`。
- 上游（external）应用接入时，在管理后台应用表单复制 `AAP_SIGN_SECRET` 自行配置。
- 没勾选 passUser 时头不存在：模板的 `current_user()` 返回 `None`，按匿名处理。

> ⚠️ 规范只写明了 payload 字段与"重算 HMAC + 常量时间比对"，**没有写明头值的编码（base64url / 原始 JSON）与签名的编码（hex / base64）**。`templates/persistent/mod.py` 的 `current_user()` 对这些格式做了宽容解析，但属于推断实现——**首次上传试运行时用真实请求核对一次**，对不上就按实际格式收紧。

invoked 应用按用户隔离：从 `input` 里的调用者字段取 user_key（具体字段名以平台入参 Schema 为准）。

## 统一页面元素（persistent）

平台会在你的 HTML 响应里**自动注入**一个悬浮条：AI超级面板 / 个人中心 / 退出登录（已登录时显示用户名）。

1. **不得遮挡、覆盖、隐藏**这些按钮：不放全屏遮罩，不用 `z-index` 压住右上角。
2. 右上角**预留空间**（建议 220×48px），自己的导航避开。
3. **不要自建登录/登出/个人中心入口**——会话由平台统一管理，自建会破坏单点登录。
4. HTML 工具无需处理：它们在平台外壳的 iframe 里，顶部 chrome 由平台提供。

## 沙箱前端纪律

HTML 工具与 persistent 页面通用。应用在 iframe 沙箱（opaque origin）里运行：

1. **禁用 `localStorage` / `sessionStorage` / `document.cookie`**：沙箱下访问直接抛 `SecurityError`，所在脚本段整段崩溃。持久化交给后端 `aap.db`，页面状态用内存变量。
2. **密钥零出现**：配置/密钥走 manifest `env`；前端输入框收集密钥 = 设计错误（泄露面大，且与计费/审计脱节）。
3. **全部相对路径**：`./api/x`、`./static/x.css`，不要 `/api/x`。
4. **剪贴板降级**：`navigator.clipboard` 可能被拒，必须带 `document.execCommand('copy')` 降级（模板里有现成 `copyText()`）。
5. **右上角留白**（persistent）。
6. 外链 CDN 脚本/样式/字体在沙箱里可能加载失败，建议内联；HTML 工具若要自带 JS，直接写进 `index.html` 或包内静态文件。
