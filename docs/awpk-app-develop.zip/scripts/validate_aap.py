#!/usr/bin/env python3
"""静态校验 .awpk 应用包目录（manifest + 代码），对应规范 v0.2.6。

用法: python validate_aap.py <包目录>
退出码: 0 = 无 ERROR；1 = 有 ERROR。WARN 需人工判断。
"""
import ast
import json
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

CAPS = {"llm", "db", "storage"}
NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
ENV_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
RESERVED_EXACT = {"PORT", "PATH", "HOME", "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY",
                  "http_proxy", "https_proxy", "no_proxy", "NODE_OPTIONS"}
RESERVED_PREFIX = ("AAP_", "PYTHON", "SSL_CERT_", "SANDBOX_")
# 平台自动注入、代码可直接读取的变量
PLATFORM_ENV_OK = {"PORT", "AAP_APP_ID", "AAP_SIGN_SECRET", "AAP_DEBUG", "PATH", "HOME"}
# Flask 预置框架及其依赖（无需在 requirements 声明）
PRESET_MODULES = {"flask", "werkzeug", "jinja2", "markupsafe", "itsdangerous", "click", "blinker"}
FORBIDDEN_IMPORTS = {
    "socket": "自建网络出口，改用 aap.http.fetch",
    "subprocess": "沙箱禁止子进程",
    "requests": "沙箱无直连外网，改用 aap.http.fetch",
    "urllib3": "沙箱无直连外网，改用 aap.http.fetch",
    "httpx": "沙箱无直连外网，改用 aap.http.fetch",
    "aiohttp": "沙箱无直连外网，改用 aap.http.fetch",
    "ftplib": "自建网络出口",
    "smtplib": "自建网络出口",
    "telnetlib": "自建网络出口",
    "ctypes": "沙箱禁止",
    "pip": "禁止运行时自装依赖，改用 manifest requirements",
}
FORBIDDEN_FROM = {
    "urllib.request": "沙箱无直连外网，改用 aap.http.fetch",
    "http.client": "沙箱无直连外网，改用 aap.http.fetch",
}
FORBIDDEN_OS_CALLS = {"system", "popen", "execv", "execve", "execvp", "spawnv", "spawnl", "fork", "startfile"}
STATE_NAME_RE = re.compile(r"^_?(tasks?|jobs?|results?|cache|sessions?|store|state|queue)\w*$", re.I)
LOG_ROOTS = {"aap.log", "logging", "logger", "log", "LOG", "LOGGER"}


class Report:
    def __init__(self):
        self.items = []

    def error(self, msg):
        self.items.append(("ERROR", msg))

    def warn(self, msg):
        self.items.append(("WARN", msg))

    @property
    def errors(self):
        return [m for l, m in self.items if l == "ERROR"]

    def show(self):
        for lvl, msg in self.items:
            print(f"[{lvl}] {msg}")
        e, w = len(self.errors), len(self.items) - len(self.errors)
        print(f"\n结果：{e} 个 ERROR，{w} 个 WARN" + ("  ✔ 可打包" if e == 0 else "  ✘ 请先修复 ERROR"))


def dotted(node):
    """Attribute/Name 链 → 'a.b.c'，无法解析返回 None。"""
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return None


def norm_req_name(req: str) -> str:
    m = re.match(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)", req)
    return re.sub(r"[-_.]+", "-", m.group(1)).lower() if m else ""


# ───────────────────────── manifest ─────────────────────────

def check_manifest(pkg: Path, rep: Report):
    mf = pkg / "manifest.json"
    if not mf.exists():
        rep.error("缺少 manifest.json（必须位于包根目录）")
        return None
    try:
        m = json.loads(mf.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        rep.error(f"manifest.json 不是合法 JSON（注意不能有注释）：{e}")
        return None
    if not isinstance(m, dict):
        rep.error("manifest.json 顶层必须是对象")
        return None

    for k in ("name", "display_name", "version", "type", "description", "author"):
        if not m.get(k):
            rep.error(f"manifest 缺少必填字段 {k}")
    name = m.get("name", "")
    if name and not NAME_RE.match(str(name)):
        rep.error(f"name {name!r} 不合法：小写字母数字连字符，如 stock-summary")
    if m.get("version") and not re.match(r"^\d+\.\d+\.\d+", str(m["version"])):
        rep.warn(f"version {m['version']!r} 建议使用 x.y.z 形式")

    typ = m.get("type")
    if typ not in ("html", "python"):
        rep.error(f"type 必须是 'html' 或 'python'，当前 {typ!r}")
        return m

    entry = str(m.get("entry", ""))
    if not entry:
        rep.error("manifest 缺少 entry")
    elif entry.startswith("/") or ".." in Path(entry).parts or re.match(r"^[A-Za-z]:", entry):
        rep.error(f"entry {entry!r} 必须是包内相对路径（含 ../ 或绝对路径上传即拒）")
    elif not (pkg / entry).exists():
        rep.error(f"entry 指向的文件不存在：{entry}")
    if typ == "html" and entry and entry != "index.html":
        rep.error("html 包的 entry 固定为 index.html")
    if typ == "python" and entry and not entry.endswith(".py"):
        rep.error("python 包的 entry 应为 mod.py")

    runtime = m.get("runtime")
    if typ == "python":
        if runtime not in ("invoked", "persistent"):
            rep.error("python 包必须声明 runtime：'invoked' 或 'persistent'")
        if runtime == "persistent":
            route = m.get("route")
            if not route:
                rep.error("persistent 包必须声明 route（平台路由前缀）")
            elif not NAME_RE.match(str(route)):
                rep.error(f"route {route!r} 不合法：小写字母数字连字符")
    elif runtime == "persistent":
        rep.error("persistent 仅适用于 python 包")

    caps = m.get("capabilities")
    if not isinstance(caps, list):
        rep.error("capabilities 必须是数组（不需要则写 []）")
    else:
        for c in caps:
            if c not in CAPS:
                rep.error(f"未知 capability {c!r}，只允许 {sorted(CAPS)}")
    net = m.get("network")
    if not isinstance(net, list):
        rep.error("network 必须是数组（无需联网则写 []）")
    else:
        for d in net:
            if not isinstance(d, str) or not d or "://" in d or "/" in d or " " in d:
                rep.error(f"network 条目 {d!r} 必须是纯主机名（不带 scheme/路径），如 api.example.com")
            elif "*" in d:
                rep.warn(f"network 条目 {d!r} 含通配符：规范要求逐条列出域名，平台可能不支持通配")

    check_env(m.get("env"), rep)
    check_requirements(m.get("requirements"), rep)
    return m


def check_env(env, rep: Report):
    if env is None:
        return
    if not isinstance(env, dict):
        rep.error("env 必须是对象 {变量名: 描述 | 配置对象}")
        return
    if len(env) > 16:
        rep.error(f"env 变量最多 16 个，当前 {len(env)}")
    for var, spec in env.items():
        if not ENV_NAME_RE.match(var):
            rep.error(f"env 变量名 {var!r} 不合法")
        if var in RESERVED_EXACT or var.startswith(RESERVED_PREFIX):
            rep.error(f"env 变量 {var} 是平台保留名，声明会导致上传失败")
        if isinstance(spec, str):
            continue
        if not isinstance(spec, dict):
            rep.error(f"env.{var} 必须是字符串描述或配置对象")
            continue
        if spec.get("secret") and "default" in spec:
            rep.error(f"env.{var} 是机密变量，不允许 default")
        if "default" in spec and not isinstance(spec["default"], str):
            rep.error(f"env.{var}.default 必须是字符串")
        if "pattern" in spec:
            try:
                re.compile(spec["pattern"])
            except re.error as e:
                rep.error(f"env.{var}.pattern 不是合法正则：{e}")
        if not spec.get("description"):
            rep.warn(f"env.{var} 建议写 description，告诉填写者这是什么、去哪获取")
        if re.search(r"(KEY|TOKEN|SECRET|PASSWORD|PASSWD)", var, re.I) and not spec.get("secret"):
            rep.warn(f"env.{var} 看起来是密钥，建议设置 \"secret\": true（加密存储、界面只写不读）")


def check_requirements(reqs, rep: Report):
    if reqs is None:
        return
    if not isinstance(reqs, list) or not all(isinstance(r, str) for r in reqs):
        rep.error("requirements 必须是字符串数组")
        return
    for r in reqs:
        s = r.strip()
        if s.startswith("-") or "://" in s or s.startswith((".", "/", "~")) or "@" in s or " @ " in s:
            rep.error(f"requirements 条目 {r!r} 不支持 URL / 本地路径 / -r（上传即拒）")
        elif not norm_req_name(s):
            rep.error(f"requirements 条目 {r!r} 不是合法 pip 需求串")
        elif norm_req_name(s) in PRESET_MODULES or norm_req_name(s) == "flask":
            rep.warn(f"requirements 里的 {r!r} 属于平台预置框架，无需声明")
        elif not re.search(r"[<>=!~]", s):
            rep.warn(f"requirements 条目 {r!r} 未带版本约束：装当时最新版，建议加上限或精确版本")


# ───────────────────────── python 代码 ─────────────────────────

def check_python(pkg: Path, m: dict, rep: Report):
    entry = pkg / m.get("entry", "mod.py")
    if not entry.exists():
        return
    src = entry.read_text(encoding="utf-8")
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        rep.error(f"{entry.name} 语法错误：第 {e.lineno} 行 {e.msg}")
        return

    caps = set(m.get("capabilities") or [])
    network = set(m.get("network") or [])
    env_decl = set((m.get("env") or {}).keys()) if isinstance(m.get("env"), dict) else set()
    runtime = m.get("runtime")
    reqs = {norm_req_name(r) for r in (m.get("requirements") or []) if isinstance(r, str)}
    stdlib = getattr(sys, "stdlib_module_names", set())

    used = {"llm": False, "db": False, "storage": False, "http": False}
    has_handle = False

    for node in ast.walk(tree):
        # imports
        if isinstance(node, ast.Import):
            for a in node.names:
                top = a.name.split(".")[0]
                check_import(a.name, top, node.lineno, rep, stdlib, reqs)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            top = node.module.split(".")[0]
            if node.module in FORBIDDEN_FROM:
                rep.error(f"第 {node.lineno} 行：导入 {node.module} —— {FORBIDDEN_FROM[node.module]}")
            else:
                check_import(node.module, top, node.lineno, rep, stdlib, reqs)
        # handle()
        if isinstance(node, ast.FunctionDef) and node.name == "handle":
            has_handle = True
            n = len(node.args.args)
            if runtime == "invoked" and n < 2:
                rep.error(f"第 {node.lineno} 行：handle 签名应为 handle(input, aap)")
        # calls
        if isinstance(node, ast.Call):
            fn = dotted(node.func) or ""
            if fn == "print":
                rep.error(f"第 {node.lineno} 行：禁止 print()（invoked 下污染 JSON 出参协议），请用 aap.log")
            if fn in ("exec", "eval", "__import__", "compile"):
                rep.warn(f"第 {node.lineno} 行：使用了 {fn}()，沙箱审核可能拒绝")
            if fn == "open":
                mode = ""
                if len(node.args) > 1 and isinstance(node.args[1], ast.Constant):
                    mode = str(node.args[1].value)
                for kw in node.keywords:
                    if kw.arg == "mode" and isinstance(kw.value, ast.Constant):
                        mode = str(kw.value.value)
                if any(c in mode for c in "wax+"):
                    rep.warn(f"第 {node.lineno} 行：open(..., {mode!r}) 写文件——沙箱无文件写权限，改用 aap.storage")
            if fn.startswith("os.") and fn.split(".", 1)[1] in FORBIDDEN_OS_CALLS:
                rep.error(f"第 {node.lineno} 行：禁止 {fn}（沙箱无进程/系统调用）")
            if fn.startswith("aap.llm."):
                used["llm"] = True
            elif fn.startswith("aap.db."):
                used["db"] = True
            elif fn.startswith("aap.storage."):
                used["storage"] = True
            elif fn.startswith("aap.http."):
                used["http"] = True
                check_fetch(node, network, rep)
            # 日志里带环境变量值
            if any(fn == r or fn.startswith(r + ".") for r in LOG_ROOTS):
                for sub in ast.walk(node):
                    d = dotted(sub) if isinstance(sub, (ast.Attribute, ast.Name)) else None
                    if d and d.startswith("os.environ"):
                        rep.error(f"第 {node.lineno} 行：日志调用中包含 os.environ 的值（禁止把环境变量值打进日志）")
                        break
            # 读 env
            name = env_read_name(node, fn)
            if name and name not in env_decl and name not in PLATFORM_ENV_OK:
                rep.warn(f"第 {node.lineno} 行：读取环境变量 {name}，但 manifest.env 未声明（未声明则线上拿不到值）")
        # os.environ["X"]
        if isinstance(node, ast.Subscript) and dotted(node.value) == "os.environ":
            sl = node.slice
            if isinstance(sl, ast.Constant) and isinstance(sl.value, str):
                name = sl.value
                if name not in env_decl and name not in PLATFORM_ENV_OK:
                    rep.warn(f"第 {node.lineno} 行：读取环境变量 {name}，但 manifest.env 未声明（未声明则线上拿不到值）")

    # capabilities 对账
    for cap in ("llm", "db", "storage"):
        if used[cap] and cap not in caps:
            rep.error(f"代码调用了 aap.{cap}.*，但 manifest.capabilities 未声明 {cap!r}（运行时直接报错）")
        if cap in caps and not used[cap]:
            rep.warn(f"manifest 声明了 capability {cap!r} 但代码没有用到（宁少勿多，审批按声明看）")
    if used["http"] and not network:
        rep.error("代码使用了 aap.http.fetch，但 manifest.network 为空")
    if network and not used["http"]:
        rep.warn("manifest.network 声明了域名，但代码没有调用 aap.http.fetch")

    if runtime == "invoked" and not has_handle:
        rep.error("invoked 包必须定义 handle(input, aap)")

    if runtime == "persistent":
        check_persistent(src, tree, rep)

    check_hardcoded_secrets(src, rep, entry.name)
    check_frontend_text(src, entry.name, rep)


def check_import(full, top, lineno, rep, stdlib, reqs):
    if top in FORBIDDEN_IMPORTS:
        rep.error(f"第 {lineno} 行：导入 {full} —— {FORBIDDEN_IMPORTS[top]}")
        return
    if top in stdlib or top in PRESET_MODULES or top == "aap":
        return
    cand = re.sub(r"[-_.]+", "-", top).lower()
    if cand in reqs or any(r.replace("-", "") == cand.replace("-", "") for r in reqs):
        return
    rep.warn(f"第 {lineno} 行：导入第三方库 {top}，但 manifest.requirements 未声明（常见别名如 bs4→beautifulsoup4、yaml→pyyaml、PIL→pillow，确认已声明对应包）")


def env_read_name(node, fn):
    if fn in ("os.environ.get", "os.getenv") and node.args and isinstance(node.args[0], ast.Constant) \
            and isinstance(node.args[0].value, str):
        return node.args[0].value
    return None


def check_fetch(node, network, rep: Report):
    fn = dotted(node.func) or ""
    if not fn.endswith(".fetch") or not node.args:
        return
    arg = node.args[0]
    url = None
    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
        url = arg.value
    elif isinstance(arg, ast.JoinedStr) and arg.values and isinstance(arg.values[0], ast.Constant):
        url = str(arg.values[0].value)  # f-string 取前缀
    if url is None:
        rep.warn(f"第 {node.lineno} 行：aap.http.fetch 的 URL 是动态值，无法静态核对域名，请确认主机都在 manifest.network")
        return
    host = urlparse(url).hostname
    if not host:
        rep.warn(f"第 {node.lineno} 行：fetch URL 前缀 {url!r} 不含完整主机名，请人工核对域名白名单")
    elif host not in network:
        rep.error(f"第 {node.lineno} 行：fetch 的域名 {host} 未在 manifest.network 声明（未声明域名直接被代理拒绝）")


def check_persistent(src, tree, rep: Report):
    if "PORT" not in src:
        rep.error("persistent 必须通过环境变量 PORT 取监听端口（不要自己挑端口）")
    if "127.0.0.1" not in src:
        rep.error("persistent 必须 bind 到 127.0.0.1")
    for pat, what in ((r"set_cookie\(", "set_cookie"), (r"request\.cookies", "request.cookies"),
                      (r"from flask import[^\n]*\bsession\b", "flask session"),
                      (r"flask\.session", "flask.session")):
        if re.search(pat, src):
            rep.warn(f"使用了 {what}：平台会剥离沙箱响应的 Set-Cookie，不能依赖 Cookie，会话态请落 aap.db + 身份头")
    for node in tree.body:  # 仅模块级
        tgt = None
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            tgt, val = node.targets[0].id, node.value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.value is not None:
            tgt, val = node.target.id, node.value
        if tgt and STATE_NAME_RE.match(tgt):
            is_mut = isinstance(val, (ast.Dict, ast.List, ast.Set)) or \
                (isinstance(val, ast.Call) and (dotted(val.func) or "") in ("dict", "list", "set", "defaultdict", "collections.defaultdict", "OrderedDict"))
            if is_mut:
                rep.warn(f"第 {node.lineno} 行：模块级可变对象 {tgt}——若用来存任务/结果/会话，进程空闲回收（约5分钟）后会丢，应落 aap.db")
    if "x-aap-identity" in src.lower() and "AAP_SIGN_SECRET" not in src:
        rep.error("读取了 x-aap-identity 头但没有用 AAP_SIGN_SECRET 验签（未验签的身份头可伪造）")


SECRET_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9_\-]{20,}"),
    re.compile(r"(?i)(api[_-]?key|secret|token|passw(or)?d)\s*[:=]\s*['\"][A-Za-z0-9_\-./+=]{12,}['\"]"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
]


def check_hardcoded_secrets(src, rep, fname):
    for pat in SECRET_PATTERNS:
        m = pat.search(src)
        if m:
            line = src[:m.start()].count("\n") + 1
            rep.warn(f"{fname} 第 {line} 行：疑似硬编码密钥/令牌，请改用 manifest.env + os.environ")
            return


# ───────────────────────── 前端文本检查（html/js/py 内嵌页面通用） ─────────────────────────

FRONT_RULES = [
    (re.compile(r"\b(localStorage|sessionStorage)\b"), "ERROR",
     "使用了 localStorage/sessionStorage：沙箱下抛 SecurityError、整段脚本崩溃，持久化请落后端 aap.db"),
    (re.compile(r"document\.cookie"), "ERROR",
     "使用了 document.cookie：沙箱下不可用，会话态请走后端"),
    (re.compile(r"""\b(?:src|href|action)\s*=\s*["']/(?!/)"""), "ERROR",
     "出现绝对路径资源（src/href/action=\"/…\"）：应用挂在 /app/<route>/ 下，须用相对路径 ./…"),
    (re.compile(r"""\bfetch\(\s*["'`]/(?!/)"""), "ERROR",
     "fetch 使用了绝对路径 '/…'：须用相对路径 './api/…'"),
    (re.compile(r"""\burl\(\s*["']?/(?!/)"""), "WARN",
     "CSS url(/…) 绝对路径：须用相对路径"),
    (re.compile(r"""(?i)type\s*=\s*["']password["']"""), "ERROR",
     "出现 type=password 输入框：前端收集密钥/口令 = 设计错误，配置请走 manifest.env"),
    (re.compile(r"""(?i)placeholder\s*=\s*["'][^"']*(api[ _-]?key|密钥|secret|token)[^"']*["']"""), "ERROR",
     "疑似让用户在前端输入 API Key/密钥：配置请走 manifest.env"),
    (re.compile(r"""(?i)<(?:script|link)\b[^>]*(?:src|href)\s*=\s*["']https?://"""), "WARN",
     "引用了外链脚本/样式：沙箱环境下可能加载失败，建议内联到包内"),
]


def strip_comments(text: str) -> str:
    """去掉整行注释与块注释（保留换行，行号不变），避免注释里提到 localStorage 等被误报。"""
    def blank(m):
        return re.sub(r"[^\n]", " ", m.group(0))
    text = re.sub(r"<!--.*?-->", blank, text, flags=re.S)
    text = re.sub(r"/\*.*?\*/", blank, text, flags=re.S)
    text = re.sub(r"(?m)^[ \t]*(#|//).*$", blank, text)
    return text


def check_frontend_text(text, fname, rep: Report):
    text = strip_comments(text)
    for pat, lvl, msg in FRONT_RULES:
        m = pat.search(text)
        if m:
            line = text[:m.start()].count("\n") + 1
            (rep.error if lvl == "ERROR" else rep.warn)(f"{fname} 第 {line} 行：{msg}")
    if "navigator.clipboard" in text and "execCommand" not in text:
        rep.warn(f"{fname}：使用了 navigator.clipboard 但没有 execCommand('copy') 降级（沙箱下剪贴板可能被拒）")


def check_static_files(pkg: Path, m: dict, rep: Report):
    skip = {"mod.py"}
    for f in sorted(pkg.rglob("*")):
        if not f.is_file() or f.name in skip or any(p in {"__pycache__", ".deps", ".aap-dev"} for p in f.parts):
            continue
        if f.suffix.lower() in {".html", ".htm", ".js", ".css"}:
            try:
                check_frontend_text(f.read_text(encoding="utf-8"), str(f.relative_to(pkg)), rep)
            except UnicodeDecodeError:
                rep.warn(f"{f.relative_to(pkg)} 不是 UTF-8 编码，请转换")


def main() -> int:
    if len(sys.argv) != 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__)
        return 2
    pkg = Path(sys.argv[1]).resolve()
    if not pkg.is_dir():
        print(f"[错误] 不是目录：{pkg}")
        return 2
    rep = Report()
    m = check_manifest(pkg, rep)
    if m and m.get("type") == "python":
        check_python(pkg, m, rep)
    check_static_files(pkg, m or {}, rep)
    print(f"校验 {pkg.name}（type={m.get('type') if m else '?'}, runtime={m.get('runtime') if m else '?'}）\n")
    rep.show()
    return 1 if rep.errors else 0


if __name__ == "__main__":
    sys.exit(main())
