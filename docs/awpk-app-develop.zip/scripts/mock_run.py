#!/usr/bin/env python3
"""本地模拟运行 .awpk 的 Python 包（近似 aap-dev，非平台同一执行器）。

invoked:     python mock_run.py <包目录> --input input.json
persistent:  python mock_run.py <包目录> --get / --get /api/tasks   （用 Flask test client 请求，需本机装有 flask）

模拟内容：
  aap.log       输出到 stderr（带级别）
  aap.db        .aap-dev/db.sqlite（SQLite）
  aap.storage   .aap-dev/storage/
  aap.llm       mock：回声 + 固定 usage（--llm-reply 可指定固定回复）
  aap.http      强制 manifest.network 白名单；默认不真正联网，用 --http-fixture 提供 {url: {status, body}}；
                加 --live-http 才真实 GET
  env           --env KEY=VAL 或 .env.aap-dev；必填项缺失会像平台一样拒绝；default 会自动注入
  capabilities  未声明的接口调用直接抛 PermissionError（与线上一致）
这是近似模拟：超时、配额、网关侧能力闸、平台代理行为不在其内，上传后仍需试运行。
"""
import argparse
import builtins
import importlib.util
import json
import logging
import os
import sqlite3
import sys
import types
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

log = logging.getLogger("aap")


def need(manifest, cap):
    if cap not in (manifest.get("capabilities") or []):
        raise PermissionError(f"未声明 capability {cap!r}，调用 aap.{cap} 会直接报错（请在 manifest.capabilities 声明）")


class MockDB:
    def __init__(self, path: Path, manifest):
        path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._m = manifest

    def execute(self, sql, params=()):
        need(self._m, "db")
        log.debug("db.execute %s %s", sql.strip().split("\n")[0][:120], params)
        cur = self._conn.execute(sql, tuple(params))
        self._conn.commit()
        return cur.rowcount

    def query(self, sql, params=()):
        need(self._m, "db")
        log.debug("db.query %s %s", sql.strip().split("\n")[0][:120], params)
        return [dict(r) for r in self._conn.execute(sql, tuple(params)).fetchall()]


class MockStorage:
    def __init__(self, root: Path, manifest):
        self._root, self._m = root, manifest
        root.mkdir(parents=True, exist_ok=True)

    def _p(self, key):
        p = (self._root / key).resolve()
        if self._root.resolve() not in p.parents and p != self._root.resolve():
            raise ValueError("非法路径")
        return p

    def put(self, key, data):
        need(self._m, "storage")
        p = self._p(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)

    def get(self, key):
        need(self._m, "storage")
        return self._p(key).read_bytes()

    def delete(self, key):
        need(self._m, "storage")
        self._p(key).unlink(missing_ok=True)

    def list(self, prefix=""):
        need(self._m, "storage")
        base = self._root.resolve()
        return sorted(str(f.relative_to(base)) for f in base.rglob("*") if f.is_file() and str(f.relative_to(base)).startswith(prefix))


class MockLLM:
    def __init__(self, manifest, fixed_reply=None):
        self._m, self._fixed = manifest, fixed_reply

    def chat(self, messages, **opts):
        need(self._m, "llm")
        last = next((m["content"] for m in reversed(messages) if m.get("role") == "user"), "")
        reply = self._fixed if self._fixed is not None else f"[MOCK 回声] {str(last)[:200]}"
        log.debug("llm.chat MOCK model=%s max_tokens=%s", opts.get("model", "default"), opts.get("max_tokens"))
        if opts.get("stream"):
            return iter([reply[i:i + 8] for i in range(0, len(reply), 8)])
        return {"content": reply, "model": opts.get("model", "mock-model"),
                "usage": {"prompt_tokens": len(str(last)), "completion_tokens": len(reply)}}


class MockHTTP:
    def __init__(self, manifest, fixtures, live):
        self._net, self._fx, self._live = set(manifest.get("network") or []), fixtures, live

    def fetch(self, url, headers=None):
        host = urlparse(url).hostname
        allowed = host in self._net
        log.debug("http.fetch %s 白名单=%s", url, "放行" if allowed else "拒绝")
        if not allowed:
            raise PermissionError(f"域名 {host} 未在 manifest.network 声明，被代理拒绝")
        if url in self._fx:
            return self._fx[url]
        if self._live:
            req = urllib.request.Request(url, headers=headers or {})
            try:
                with urllib.request.urlopen(req, timeout=15) as r:
                    return {"status": r.status, "body": r.read(500_000).decode("utf-8", "replace")}
            except urllib.error.HTTPError as e:
                return {"status": e.code, "body": e.read(500_000).decode("utf-8", "replace")}
        raise RuntimeError(f"mock 模式不联网：请用 --http-fixture 提供 {url} 的响应，或加 --live-http")


def build_aap(manifest, workdir: Path, args):
    fixtures = json.loads(Path(args.http_fixture).read_text(encoding="utf-8")) if args.http_fixture else {}
    aap = types.SimpleNamespace()
    aap.log = log
    aap.db = MockDB(workdir / "db.sqlite", manifest)
    aap.storage = MockStorage(workdir / "storage", manifest)
    aap.llm = MockLLM(manifest, args.llm_reply)
    aap.http = MockHTTP(manifest, fixtures, args.live_http)
    return aap


def load_env(manifest, args, pkg: Path):
    vals = {}
    envfile = pkg / ".env.aap-dev"
    if envfile.exists():
        for line in envfile.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                vals[k.strip()] = v.strip()
    for kv in args.env or []:
        k, _, v = kv.partition("=")
        vals[k] = v
    problems = []
    for var, spec in (manifest.get("env") or {}).items():
        spec = {"required": True} if isinstance(spec, str) else spec
        if var not in vals and "default" in spec:
            vals[var] = spec["default"]
        if var not in vals and spec.get("required", True):
            problems.append(var)
    if problems:
        sys.exit(f"[拒绝执行] 必填环境变量未配置：{', '.join(problems)}（平台同样会拒绝执行并提示；用 --env {problems[0]}=… 或 .env.aap-dev 提供）")
    os.environ.update(vals)
    return vals


def load_module(entry: Path, aap):
    builtins.aap = aap  # 平台向 mod.py 注入全局 aap
    sys.path.insert(0, str(entry.parent))
    spec = importlib.util.spec_from_file_location("aap_user_mod", entry)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pkg", help="包目录")
    ap.add_argument("--input", help="invoked 入参 JSON 文件（缺省读 stdin）")
    ap.add_argument("--get", action="append", help="persistent：要请求的路径，可多次")
    ap.add_argument("--post", action="append", help="persistent：'路径=JSON'，如 /api/tasks={\"prompt\":\"hi\"}")
    ap.add_argument("--env", action="append", help="KEY=VAL，可多次")
    ap.add_argument("--llm-reply", help="mock LLM 固定回复")
    ap.add_argument("--http-fixture", help="JSON：{url: {status, body}}")
    ap.add_argument("--live-http", action="store_true", help="真实 GET（仍强制白名单）")
    ap.add_argument("--reset", action="store_true", help="清空本地 db/storage")
    ap.add_argument("-q", "--quiet", action="store_true", help="不输出 DEBUG 日志")
    args = ap.parse_args()

    pkg = Path(args.pkg).resolve()
    manifest = json.loads((pkg / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("type") != "python":
        sys.exit("html 包无需运行：用浏览器直接打开 index.html，并留意控制台是否有 SecurityError。")

    workdir = pkg / ".aap-dev"
    if args.reset and workdir.exists():
        import shutil
        shutil.rmtree(workdir)

    logging.basicConfig(level=logging.INFO if args.quiet else logging.DEBUG,
                        format="[%(levelname)s] %(message)s", stream=sys.stderr)
    load_env(manifest, args, pkg)
    aap = build_aap(manifest, workdir, args)
    runtime = manifest.get("runtime")

    if runtime == "invoked":
        raw = Path(args.input).read_text(encoding="utf-8") if args.input else sys.stdin.read() or "{}"
        mod = load_module(pkg / manifest["entry"], aap)
        result = mod.handle(json.loads(raw), aap)
        try:
            out = json.dumps(result, ensure_ascii=False, indent=2)
        except TypeError as e:
            sys.exit(f"[失败] handle() 返回值不可 JSON 序列化：{e}（二进制请存 aap.storage 返回路径）")
        print(out)
        if isinstance(result, dict) and "error" in result:
            print("（handle 返回了 error，请确认这是预期的失败路径）", file=sys.stderr)
        return 0

    # persistent
    os.environ.setdefault("PORT", "8080")
    os.environ.setdefault("AAP_APP_ID", manifest.get("name", "app"))
    try:
        mod = load_module(pkg / manifest["entry"], aap)
    except ModuleNotFoundError as e:
        sys.exit(f"[失败] 缺少模块 {e.name}：本机需安装 flask 才能模拟 persistent（pip install flask）")
    flask_app = getattr(mod, "app", None)
    if flask_app is None:
        sys.exit("[失败] persistent 包的 mod.py 里没有找到 Flask 实例 `app`（模拟器只支持 Flask）")
    client = flask_app.test_client()
    for path in args.get or ["/"]:
        r = client.get(path)
        body = r.get_data(as_text=True)
        print(f"GET {path} -> {r.status_code}\n{body[:600]}{'…' if len(body) > 600 else ''}\n")
    for item in args.post or []:
        path, _, payload = item.partition("=")
        r = client.post(path, json=json.loads(payload or "{}"))
        print(f"POST {path} -> {r.status_code}\n{r.get_data(as_text=True)[:600]}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
