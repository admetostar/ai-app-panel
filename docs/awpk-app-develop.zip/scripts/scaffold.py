#!/usr/bin/env python3
"""从模板创建 .awpk 应用骨架。

用法: python scaffold.py <invoked|persistent|html> <包名> [--out DIR]
包名: 小写字母数字连字符，如 stock-summary
"""
import argparse
import re
import shutil
import sys
from pathlib import Path

TEMPLATES = Path(__file__).resolve().parent.parent / "assets" / "templates"
NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("kind", choices=["invoked", "persistent", "html"])
    ap.add_argument("name")
    ap.add_argument("--out", default=".", help="输出父目录（默认当前目录）")
    args = ap.parse_args()

    if not NAME_RE.match(args.name):
        print(f"[错误] 包名 {args.name!r} 不合法：只能是小写字母、数字和连字符，如 stock-summary", file=sys.stderr)
        return 2
    dest = Path(args.out) / args.name
    if dest.exists():
        print(f"[错误] 目录已存在：{dest}", file=sys.stderr)
        return 2

    shutil.copytree(TEMPLATES / args.kind, dest)
    for f in dest.rglob("*"):
        if f.is_file() and f.suffix in {".json", ".py", ".html"}:
            f.write_text(f.read_text(encoding="utf-8").replace("__NAME__", args.name), encoding="utf-8")

    print(f"已创建 {args.kind} 模板：{dest}")
    for f in sorted(dest.rglob("*")):
        if f.is_file():
            print("  ", f.relative_to(dest))
    print("\n下一步：编辑 manifest.json（display_name/description/capabilities/network/env）和入口文件，")
    print(f"然后运行 validate_aap.py {dest}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
