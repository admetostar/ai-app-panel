#!/usr/bin/env python3
"""校验并打包为 .awpk（ZIP，manifest.json 位于根部）。

用法: python pack_aap.py <包目录> [--out DIR] [--force]
默认先运行 validate_aap.py 的全部检查，有 ERROR 则拒绝打包（--force 可跳过，不推荐）。
输出文件名: <name>-<version>.awpk
"""
import argparse
import json
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXCLUDE_DIRS = {"__pycache__", ".aap-dev", ".deps", ".git", ".venv", "node_modules"}
EXCLUDE_NAMES = {".DS_Store", ".env.aap-dev"}
EXCLUDE_SUFFIX = {".pyc", ".awpk", ".zip"}


def skip(path: Path, pkg: Path) -> bool:
    rel = path.relative_to(pkg)
    if any(p in EXCLUDE_DIRS for p in rel.parts):
        return True
    if path.name in EXCLUDE_NAMES or path.suffix in EXCLUDE_SUFFIX:
        return True
    # 调试用的示例入参不进包
    if path.name.startswith("input") and path.suffix == ".json" and path.name != "manifest.json":
        return True
    return False


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pkg")
    ap.add_argument("--out", default=".")
    ap.add_argument("--force", action="store_true", help="校验有 ERROR 也强行打包")
    args = ap.parse_args()

    pkg = Path(args.pkg).resolve()
    if not (pkg / "manifest.json").exists():
        print("[错误] 目录下没有 manifest.json")
        return 2

    rc = subprocess.call([sys.executable, str(HERE / "validate_aap.py"), str(pkg)])
    if rc != 0 and not args.force:
        print("\n校验未通过，已中止打包。")
        return 1

    m = json.loads((pkg / "manifest.json").read_text(encoding="utf-8"))
    out_dir = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{m['name']}-{m['version']}.awpk"

    files = [f for f in sorted(pkg.rglob("*")) if f.is_file() and not skip(f, pkg)]
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f, f.relative_to(pkg).as_posix())

    print(f"\n已打包：{out}  ({out.stat().st_size / 1024:.1f} KB)")
    for f in files:
        print("  +", f.relative_to(pkg).as_posix())
    return 0


if __name__ == "__main__":
    sys.exit(main())
